# Gold 原版 Script API 迁移说明

脚本入口为 `scripts/main.js`，行为包仍保留原有 `functions/`、`items/`、`structures/` 和 `tick.json`。本实现按本地 `sapi-typedoc-main` 的 `@minecraft/server 2.10.0-beta` 接口编写，要求使用对应的 1.26.40 Preview/Beta 服务端。

已迁移：

- 丹药/草药食用效果（通过 `gold:consume` 原版物品自定义组件）。
- 计分板属性、装备攻击/防御计算、武器镜像、命中/暴击/护盾/吸血/死亡播报。
- Title 提示与属性变化提示。

以下功能按你的要求不移植：

- `simplebancmd` 的全局命令封禁。
- `config/*.json`、`playerdata/*.json` 的读写和 `bugshuju` 数据备份。
- `bug666` 的设备/IP/网络信息查询。
- Script API 没有旧版物品 `aux/data` 字段，陶片的 `data=10` 细分无法一比一识别；迁移代码按物品类型处理。
- 每名玩家独立 Sidebar。
- LL 自定义命令及命令别名（包括命名空间命令）。
