import { system, world } from "@minecraft/server";
import { getScore, tell } from "./score.js";
import { gf, zjqw } from "./format.js";

// 需要提示玩家的永久属性。Script API 没有通用“计分板变化事件”，只能定时比较前后值。
const ATTR_NAMES = { hp2: "§c生命上限", ll2: "§9灵力上限", hl: "§5回灵", hx: "§c回血", bj: "§6暴击", bs: "§3暴伤", zs: "§f真伤", atk: "§4攻击力", sb: "§e闪避", fy: "§f防御" };
const watched = Object.keys(ATTR_NAMES);

// 组装修仙状态标题。这里只负责原 Gold.js 的 xqcd/gftime Title，不再模拟独立 Sidebar。
function cultivationText(player) {
  let text = `§f[§c修仙状态§f]§8 -- §f${player.name}§7\n§f▁▁▁▁▁▁▁▁▁▁▁▁▁▁\n§0▪ §b灵石: §f${getScore(player, "ls")}    §0▪§e 耀金: §f${getScore(player, "yj")}\n§1▪ §3修道: §f${getScore(player, "day")} 载\n§2▪ §d剧情: §f${getScore(player, "jq")}    §2▪§5 任务: §f${getScore(player, "rw")}`;
  if (getScore(player, "tdqw") >= 1) text += `\n§3▪ §a筑基奇物：§r ${zjqw(getScore(player, "tdqw"))}`;
  if (getScore(player, "gf") >= 1) text += `\n${gf(getScore(player, "gf"))}`;
  return text;
}

export function registerStatus() {
  // key 格式为“玩家运行时 id:目标名”，值为上次轮询到的分数。
  // 第一次读取只建立基线，不发送“属性变化”消息。
  const previous = new Map();
  // 每 5 tick 检查一次，在提示及时性和服务器开销之间取平衡。
  system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
      try {
        const xqcd = getScore(player, "xqcd");
        const gftime = getScore(player, "gftime");
        // 正在突破时不覆盖突破流程自己的屏幕提示。
        if (!player.hasTag("tpsj") && xqcd === 4) player.onScreenDisplay.setTitle(cultivationText(player), { stayDuration: 20, fadeInDuration: 0, fadeOutDuration: 0 });
        else if (!player.hasTag("tpsj") && gftime >= 1 && xqcd === 0) player.onScreenDisplay.setTitle(`--------[领悟功法中]--------\n§0▪ §f时间: §f${gftime}s\n§3▪ §b灵力: §f${getScore(player, "ll")}/${getScore(player, "ll2")}${getScore(player, "ll") <= 10 ? "\n§4▪ §f当前灵力过低，无法继续领悟功法！" : ""}\n${gf(getScore(player, "gf"))}`, { stayDuration: 20, fadeInDuration: 0, fadeOutDuration: 0 });
        const key = player.id;
        for (const objective of watched) {
          const value = getScore(player, objective);
          const old = previous.get(`${key}:${objective}`);
          if (old !== undefined && old !== value) tell(player, `[属性变化] ${ATTR_NAMES[objective]} 变为${value}`);
          previous.set(`${key}:${objective}`, value);
        }
      } catch { /* 玩家在此 tick 卸载 */ }
    }
  }, 5);
}
