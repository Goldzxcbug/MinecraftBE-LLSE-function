import { EquipmentSlot, ItemLockMode, ItemStack, system, world } from "@minecraft/server";
import { addScore, getScore, hasScore, setScore, tell } from "./score.js";
import { gf, zjqw } from "./format.js";

// 原版武器 typeId -> [额外攻击力, wqlx 武器编号]。
// wqlx 继续复用旧函数包的编号约定，避免影响现有 mcfunction 判断。
const weaponAttack = {
  "minecraft:wooden_axe": [4, 1], "minecraft:stone_axe": [9, 2], "minecraft:iron_axe": [13, 3],
  "minecraft:golden_axe": [18, 4], "minecraft:diamond_axe": [21, 5], "minecraft:netherite_axe": [24, 6],
  "minecraft:wooden_sword": [4, 7], "minecraft:stone_sword": [5, 8], "minecraft:iron_sword": [6, 9],
  "minecraft:golden_sword": [7, 10], "minecraft:diamond_sword": [10, 11], "minecraft:netherite_sword": [13, 12]
};

// 旧插件中不同武器的攻击间隔（tick）。当前文件保留这张兼容表，供后续恢复攻速限制使用。
const attackSpeedTicks = { 1: 25, 2: 20, 3: 20, 4: 10, 5: 15, 6: 12, 7: 10, 8: 8, 9: 6, 10: 4, 11: 6, 12: 6 };

// 安全读取实体背包槽。实体卸载、没有 inventory 组件或槽位无物品时统一返回 undefined。
function containerItem(player, slot) {
  try { return player.getComponent("minecraft:inventory")?.container?.getItem(slot); } catch { return undefined; }
}

// Gold 使用自己的防御数值，因此不读取原版 armor/toughness 属性，而是按旧插件表手动加防御。
// 旧代码只统计胸甲、护腿和靴子，头盔不参与该自定义防御公式。
function armorValue(item) {
  if (!item) return 0;
  return {
    "minecraft:leather_chestplate": 3, "minecraft:iron_chestplate": 6, "minecraft:golden_chestplate": 15, "minecraft:diamond_chestplate": 9, "minecraft:netherite_chestplate": 11,
    "minecraft:leather_leggings": 2, "minecraft:iron_leggings": 5, "minecraft:golden_leggings": 13, "minecraft:diamond_leggings": 7, "minecraft:netherite_leggings": 9,
    "minecraft:leather_boots": 1, "minecraft:iron_boots": 4, "minecraft:golden_boots": 10, "minecraft:diamond_boots": 5, "minecraft:netherite_boots": 6
  }[item.typeId] ?? 0;
}

// 解析隐藏武器槽中的真实武器，并决定热栏 0 槽显示什么物品。
// Script API 没有 LL 的 item.aux/data，因此陶片只能按 typeId 识别，无法再判断 data=10。
function weaponInfo(item) {
  if (!item) return { attack: 0, weaponType: 0, displayType: undefined };
  const base = weaponAttack[item.typeId];
  if (base) return { attack: base[0], weaponType: base[1], displayType: item.typeId };
  if (item.typeId === "minecraft:archer_pottery_sherd") return { attack: 15, weaponType: 13, displayType: "minecraft:fishing_rod" };
  if (item.typeId === "minecraft:flow_pottery_sherd") return { attack: 20, weaponType: 14, displayType: "minecraft:fishing_rod" };
  if (item.typeId === "minecraft:amethyst_cluster") return { attack: 30, weaponType: 13, displayType: "minecraft:fishing_rod" };
  return { attack: 0, weaponType: 0, displayType: undefined };
}

// 返回顺序必须保持稳定，战斗公式依赖数组索引：
// [攻击, 防御, 灵力, 暴击率, 暴伤, 命中, 真伤, 闪避, 护盾, 攻击减免, 吸血]。
// itemOverride 主要供背包变化事件使用；没有传入时沿用旧设计，从背包第 9 槽读取真实武器。
export function getAttributes(entity, itemOverride) {
  let attack = getScore(entity, "atk") + getScore(entity, "ksatk");
  let defense = getScore(entity, "fy") + getScore(entity, "ksfy");
  const values = [attack, defense, getScore(entity, "ll"), getScore(entity, "bj"), getScore(entity, "bs"), getScore(entity, "mz"), getScore(entity, "zs"), getScore(entity, "sb"), getScore(entity, "shxs"), getScore(entity, "atkjm"), getScore(entity, "xx")];
  const item = itemOverride ?? containerItem(entity, 9);
  const info = weaponInfo(item);
  values[0] += info.attack;
  // 写回 wqlx，让现有函数和其他模块仍能知道当前武器类别。
  setScore(entity, "wqlx", info.weaponType);
  try {
    const equipment = entity.getComponent("minecraft:equippable");
    defense += armorValue(equipment?.getEquipment(EquipmentSlot.Chest));
    defense += armorValue(equipment?.getEquipment(EquipmentSlot.Legs));
    defense += armorValue(equipment?.getEquipment(EquipmentSlot.Feet));
  } catch { /* 非生物或实体未加载装备组件 */ }
  values[1] = defense;
  return values;
}

// 旧玩法把真实武器放在背包槽 9，把一个锁槽的外观物品放到热栏槽 0。
// ItemLockMode.slot 可防止玩家移动/丢弃展示物品；特殊武器统一伪装成钓鱼竿。
function refreshWeaponDisplay(player, hiddenItem) {
  try {
    const inventory = player.getComponent("minecraft:inventory")?.container;
    if (!inventory) return;
    const info = weaponInfo(hiddenItem);
    if (!info.displayType) {
      inventory.setItem(0, undefined);
      return;
    }
    const display = new ItemStack(info.displayType, 1);
    display.lockMode = ItemLockMode.slot;
    if (hiddenItem?.nameTag) display.nameTag = hiddenItem.nameTag;
    inventory.setItem(0, display);
  } catch (error) { console.warn(`[Gold] weapon display: ${error}`); }
}

// 用玩家动态属性缓存武器签名，只有 typeId/名称/数量变化时才重建展示物品。
// 这能避免每 5 tick 都写背包并反复触发背包变化事件。
function updatePlayerWeapon(player) {
  const item = containerItem(player, 9);
  const signature = item ? `${item.typeId}|${item.nameTag ?? ""}|${item.amount}` : "empty";
  if (player.getDynamicProperty("gold:lastWeapon") === signature) return;
  player.setDynamicProperty("gold:lastWeapon", signature);
  getAttributes(player, item);
  refreshWeaponDisplay(player, item);
}

// 伤害提示只发给攻击者本人。
// 这里的 ActionBar 是旧攻击伤害提示的替代，不是已经取消迁移的常驻 Sidebar 状态栏。
function displayDamage(attacker, defender, damage, critical) {
  if (!attacker || attacker.typeId !== "minecraft:player") return;
  try {
    if (damage === null) attacker.onScreenDisplay.setActionBar("Miss");
    else attacker.onScreenDisplay.setActionBar(`${critical ? "§4" : ""}${damage}  §7HP:${getScore(defender, "hp")}/${getScore(defender, "hp2")}`);
    setScore(attacker, "sjshxs", 0);
    setScore(attacker, "xxxs", 0);
  } catch { /* 玩家已离线 */ }
}

// 根据死亡者境界决定播报文本和可见半径；只通知同维度且在半径内的玩家。
function deathMessage(player, attacker) {
  const dj = getScore(player, "dj");
  let message = "";
  if (dj >= 1 && dj <= 4) message += `§a§l练气修士§f${player.name},凡修道${getScore(player, "day")}载`;
  else if (dj >= 5 && dj <= 8) message += `§7§l筑基修士§f${player.name},凡修道${getScore(player, "day")}载`;
  else if (dj >= 9 && dj <= 12) message += `§g§l金丹修士§f${player.name},凡修道${getScore(player, "day")}载`;
  else if (dj >= 13 && dj <= 16) message += `§e§l元婴修士§f${player.name},凡修道${getScore(player, "day")}载`;
  else if (dj >= 17 && dj <= 20) message += `§6§l化神修士§f${player.name},凡修道${getScore(player, "day")}载`;
  else if (dj >= 21 && dj <= 24) message += `§4§l合道修士§f${player.name},凡修道${getScore(player, "day")}载`;
  if (dj > 4) message += `以奇物${zjqw(getScore(player, "tdqw"))}§l成就道基`;
  if (dj > 8) message += `以${gf(getScore(player, "gf"))}§l成就金丹`;
  message += attacker ? `被${attacker.name ?? "未知"}所杀,如今身死道消,还道于天!` : "不慎被未知伤害所杀,如今身死道消,还道于天!";
  const radius = dj <= 4 ? 100 : dj <= 8 ? 300 : dj <= 12 ? 500 : dj <= 16 ? 1000 : dj <= 20 ? 5000 : 100000000;
  try {
    for (const viewer of world.getAllPlayers()) {
      if (viewer.dimension.id !== player.dimension.id) continue;
      const dx = viewer.location.x - player.location.x;
      const dy = viewer.location.y - player.location.y;
      const dz = viewer.location.z - player.location.z;
      if (dx * dx + dy * dy + dz * dz <= radius * radius) tell(viewer, message);
    }
  } catch { /* 实体卸载 */ }
}

// 在原版伤害已被 beforeEvents.entityHurt 取消后，结算 Gold 自定义伤害。
function resolveCombat(defender, attacker) {
  if (!defender || !attacker) return;
  try {
    if (!defender.isValid || !attacker.isValid) return;
    const target = getAttributes(defender);
    const source = getAttributes(attacker);
    // 解构名称分别对应 getAttributes 上方说明的固定数组顺序。
    const [_, defense, , , , , trueDamage, evade, shield, mitigation] = target;
    let [attack, , , critChance, critDamage, accuracy, , , , , lifeSteal] = source;
    // 命中率 = 100 - 防守者闪避 + 攻击者命中，最终限制在 0..100。
    const hitChance = Math.max(0, Math.min(100, 100 - evade + accuracy));
    if (Math.random() * 100 >= hitChance) { displayDamage(attacker, defender, null, false); return; }
    // 普通伤害先产生 80%..120% 波动；critical_hit 标签是额外 1.5 倍倍率。
    attack = Math.floor(attack * (80 + Math.floor(Math.random() * 41)) / 100);
    if (attacker.hasTag?.("critical_hit")) attack = Math.floor(attack * 1.5);
    let critical = false;
    // 暴击命中后，倍率为 (100 + 暴伤)%；例如暴伤 50 表示 1.5 倍。
    if (Math.random() * 100 < critChance) { attack = Math.floor(attack * (critDamage + 100) / 100); critical = true; }
    // 防御足够时只造成真伤；防御不足时造成“攻击-防御”，再进入护盾结算。
    let damage = defense - attack > 0 ? trueDamage : attack - defense;
    let nextShield = shield;
    // 护盾只吸收普通伤害，真伤始终保留。护盾不足时扣完剩余护盾。
    if (nextShield >= damage) { nextShield -= damage; damage = trueDamage; }
    else { damage = damage + trueDamage - nextShield; nextShield = 0; }
    // 吸血按照最终护盾前伤害百分比取整，并记录到 xxxs 临时统计分数。
    const life = Math.floor(Math.max(0, damage) * (lifeSteal / 100));
    if (life > 0) { addScore(attacker, "xxxs", life); addScore(attacker, "hp", life); }
    if (damage >= 0) {
      addScore(attacker, "sjshxs", damage);
      // atkjm 是百分比减伤；数值 20 表示最终受到 80% 伤害。
      const reduced = mitigation > 0 ? Math.floor(damage * (100 - mitigation) / 100) : damage;
      addScore(defender, "hp", -reduced);
      setScore(defender, "shxs", nextShield);
    }
    displayDamage(attacker, defender, damage, critical);
    if (getScore(defender, "hp") <= 0) {
      if (defender.typeId === "minecraft:player") {
        deathMessage(defender, attacker);
        defender.kill();
        // 自定义 hp 在死亡后先回到 10，后续复活/函数流程再负责完整恢复。
        setScore(defender, "hp", 10);
      } else defender.kill();
    }
  } catch (error) { console.warn(`[Gold] combat: ${error}`); }
}

// 同一实体两次结算至少间隔 2 tick（约 100ms），对应旧插件的 hurtCooldown。
const lastHurt = new Map();

export function registerCombat() {
  world.beforeEvents.entityHurt.subscribe((event) => {
    const defender = event.hurtEntity;
    const attacker = event.damageSource?.damagingEntity;
    // 只有已经拥有 hp 分数的 Gold 实体才接管伤害；自然伤害或普通原版实体保持原版行为。
    if (!defender || !attacker || !hasScore(defender, "hp")) return;
    const key = defender.id;
    if ((system.currentTick - (lastHurt.get(key) ?? -1000)) < 2) { event.cancel = true; return; }
    lastHurt.set(key, system.currentTick);
    // before 事件中必须立即取消原版伤害，否则会同时扣原版生命和自定义 hp。
    event.cancel = true;
    // before 回调属于受限执行上下文，修改计分板、击杀和 UI 必须延迟到下一 tick。
    system.run(() => resolveCombat(defender, attacker));
  });

  // 玩家背包第 9 槽变化时立即刷新武器属性和热栏 0 槽展示物。
  world.afterEvents.playerInventoryItemChange.subscribe(({ player, inventoryType, slot }) => {
    if (inventoryType === "Hotbar" && slot === 0) return;
    if (slot === 9) updatePlayerWeapon(player);
  });

  // 每 5 tick 再轮询一次作为保险，覆盖命令替换物品等可能没有及时触发事件的情况。
  // 玩家没有选择热栏 0 槽时施加高等级虚弱，维持旧玩法“必须手持展示武器”的限制。
  system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
      updatePlayerWeapon(player);
      if (player.selectedSlotIndex !== 0) {
        try { player.addEffect("minecraft:weakness", 20, { amplifier: 4, showParticles: false }); } catch { /* ignore */ }
      }
    }
  }, 5);
}
