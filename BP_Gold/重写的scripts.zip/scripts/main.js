import { system, world } from "@minecraft/server";
import { registerCombat } from "./combat.js";
import { registerConsumables } from "./consumables.js";
import { ensureObjectives } from "./score.js";
import { registerStatus } from "./status.js";

// startup 是脚本最早的注册阶段。
// 物品自定义组件只能在这里通过 ItemComponentRegistry 注册，世界加载后再注册会失败。
system.beforeEvents.startup.subscribe(({ itemComponentRegistry }) => {
  registerConsumables(itemComponentRegistry);
});

// worldLoad 触发时世界计分板已经可以安全访问。
// 这里只补齐缺失目标，不会清空或重建旧世界已有的分数。
world.afterEvents.worldLoad.subscribe(() => {
  ensureObjectives();
  console.warn("[Gold] 原版 Script API 迁移模块已加载");
});

// 战斗和状态模块只需要安装事件监听，可以在脚本入口加载时直接注册。
registerCombat();
registerStatus();
