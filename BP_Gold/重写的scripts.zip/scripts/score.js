import { world } from "@minecraft/server";

// Gold 旧函数包与脚本共同使用的核心计分板目标。
// 此处只保证目标存在；具体初始值仍由原来的 qz/xwj 等 mcfunction 负责。
export const REQUIRED_OBJECTIVES = [
  "hp", "hp2", "ll", "ll2", "atk", "fy", "bj", "bs", "mz", "zs", "sb",
  "shxs", "atkjm", "xx", "ksatk", "ksatkt", "ksfy", "ksfyt", "kshx", "kshxt",
  "kshl", "kshlt", "sjshxs", "xxxs", "wqlx", "xwa", "gftime", "xqcd", "ls",
  "yj", "day", "jq", "rw", "dj", "jy", "jy2", "tdqw", "gf", "uuid"
];

export function ensureObjectives() {
  for (const id of REQUIRED_OBJECTIVES) {
    if (!world.scoreboard.getObjective(id)) {
      try { world.scoreboard.addObjective(id, id); } catch { /* 可能由函数包稍后创建 */ }
    }
  }
}

// 统一读取实体/玩家分数。
// 原版 API 没有 player.getScore，必须先获取 Objective，再用实体的 scoreboardIdentity 查询。
// 目标不存在、实体卸载或还没有该分数时返回 fallback，避免一个坏分数中断整个 tick。
export function getScore(target, objectiveId, fallback = 0) {
  try {
    const objective = world.scoreboard.getObjective(objectiveId);
    if (!objective) return fallback;
    const participant = target?.scoreboardIdentity ?? target;
    const value = objective.getScore(participant);
    return typeof value === "number" ? value : fallback;
  } catch {
    return fallback;
  }
}

// 判断目标是否已经是某计分板的参与者。
// 战斗系统用它区分 Gold 自定义血量实体和普通原版实体，避免接管所有原版伤害。
export function hasScore(target, objectiveId) {
  try {
    const objective = world.scoreboard.getObjective(objectiveId);
    if (!objective) return false;
    return objective.hasParticipant(target?.scoreboardIdentity ?? target);
  } catch {
    return false;
  }
}

// 写入整数分数。目标不存在时尝试即时创建，以兼容没有先运行初始化函数的新世界。
export function setScore(target, objectiveId, value) {
  try {
    let objective = world.scoreboard.getObjective(objectiveId);
    if (!objective) objective = world.scoreboard.addObjective(objectiveId, objectiveId);
    return objective.setScore(target?.scoreboardIdentity ?? target, Math.trunc(Number(value) || 0));
  } catch {
    return undefined;
  }
}

// 原版 ScoreboardObjective 虽然有 addScore，这里仍通过“读后写”统一处理不存在的目标。
export function addScore(target, objectiveId, value) {
  return setScore(target, objectiveId, getScore(target, objectiveId) + (Number(value) || 0));
}

// 保留旧代码的 reduceScore 语义：传入正数，实际从当前分数扣除。
export function removeScore(target, objectiveId, value) {
  return addScore(target, objectiveId, -(Number(value) || 0));
}

// 玩家可能在定时回调执行前离线，因此消息与命令封装都需要吞掉实体失效异常。
export function tell(target, message) {
  try { target?.sendMessage(String(message)); } catch { /* 玩家可能已离线 */ }
}

export function run(target, command) {
  try { return target.runCommand(command); } catch { return undefined; }
}
