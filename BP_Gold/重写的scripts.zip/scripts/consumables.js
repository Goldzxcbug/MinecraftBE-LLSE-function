import { system } from "@minecraft/server";
import { addScore, getScore, removeScore, run, setScore, tell } from "./score.js";

// 合并同一类临时 Buff，而不是简单覆盖旧效果：
// - 新等级不高于旧等级：保留旧等级，并按等级比例折算新增时长。
// - 新等级更高：提升到新等级，并把旧剩余时间按比例折算后继承。
// prefix 对应 kshx/kshxt、kshl/kshlt、ksatk/ksatkt、ksfy/ksfyt。
function effect(player, currentLevel, currentTime, level, time, prefix) {
  const a = Math.max(0, Number(currentLevel) || 0);
  const atime = Math.max(0, Number(currentTime) || 0);
  let nextLevel;
  let nextTime;
  if (a >= level) {
    nextLevel = a;
    nextTime = atime + time * level / Math.max(a, 1);
  } else {
    nextLevel = level;
    nextTime = time + atime * a / Math.max(level, 1);
  }
  setScore(player, `ks${prefix}`, nextLevel);
  setScore(player, `ks${prefix}t`, Math.trunc(nextTime));
}

// 原插件会通知外部 Usf 包刷新热栏。该包不存在时 runCommand 会失败，但不会影响丹药主体效果。
function tryHotbarRefresh(player) {
  try { run(player, "scriptevent usf:command hotbar 1"); } catch { /* 外部 Usf 包可选 */ }
}

// 物品 typeId -> 食用完成后的计分板/原版效果处理。
// 时间单位：addEffect 使用 tick（20 tick = 1 秒）；自定义 Buff 的 *t 计分板沿用旧包的秒数。
const handlers = {
  "gold:fr_hx": (p) => { addScore(p, "hp", 100); tell(p, "你饮食了 §r§f§l[§gE+§f]§c生命§f丹 §r§4♥§f +100"); },
  "gold:fr_ys": (p) => p.addEffect("minecraft:night_vision", 10000, { amplifier: 1, showParticles: false }),
  "gold:fr_jp": (p) => p.addEffect("minecraft:haste", 6000, { amplifier: 1, showParticles: false }),
  "gold:fr_sd": (p) => p.addEffect("minecraft:speed", 8000, { amplifier: 2, showParticles: false }),
  "gold:lq_llllz": (p) => { p.addEffect("minecraft:night_vision", 10000, { amplifier: 1, showParticles: false }); addScore(p, "hp", 500); addScore(p, "xwa", 20); tell(p, "你食用了 §r§f§l[§gE++§f]§f玲珑§b琉璃珠 §r§4♥§f +500"); },
  "gold:lq_llyr": (p) => { addScore(p, "hp", 100); tell(p, "你食用了 §r§f§l[§gE+§f]§b琉璃鱼肉 §r§4♥§f +100"); },
  "gold:lq_lqd": (p) => {
    // 练气丹只有凡人至练气后期且修为达到 jy2 时才进入突破流程。
    const dj = getScore(p, "dj");
    if (dj <= 3 && getScore(p, "jy") >= getScore(p, "jy2")) {
      p.addTag("tpsj"); tell(p, "§a§l[提示] 食用成功");
    } else if (dj <= 3) tell(p, "§4§l[提示] 食用失败，修为不足");
    else tell(p, "§4§l[提示] 食用失败，等级不对");
  },
  "gold:lq_lld": (p) => { tell(p, "你食用了 §r§f§l[§eD§f]§b琉璃§f丹"); effect(p, getScore(p, "kshx"), getScore(p, "kshxt"), 5, 60, "hx"); effect(p, getScore(p, "kshl"), getScore(p, "kshlt"), 5, 60, "hl"); removeScore(p, "gftime", 60); addScore(p, "xwa", 40); tryHotbarRefresh(p); },
  "gold:cy_llh": (p) => { tell(p, "你食用了 §r§f§l[§eD+§f]§9灵力§f花"); removeScore(p, "hp", 4); addScore(p, "ll", 40); },
  "gold:cy_lwc": (p) => { tell(p, "你食用了 §r§f§l[§eD+§f]§9灵雾§f草"); removeScore(p, "hp", 5); removeScore(p, "ll", 13); effect(p, getScore(p, "kshl"), getScore(p, "kshlt"), 5, 60, "hl"); tryHotbarRefresh(p); },
  "gold:cy_qxc": (p) => { tell(p, "你食用了 §r§f§l[§eD+§f]§c气血§f草"); removeScore(p, "hp", 10); effect(p, getScore(p, "kshx"), getScore(p, "kshxt"), 10, 10, "hx"); tryHotbarRefresh(p); },
  "gold:cy_jjs": (p) => { tell(p, "你食用了 §r§f§l[§gD+§f] §f§e金精§f参§f"); removeScore(p, "hp", 500); },
  "gold:cy_xjr": (p) => { tell(p, "你食用了 §r§f§l[§gD+§f] §f§4血蛟§b兰§f"); removeScore(p, "hp", 50); effect(p, getScore(p, "ksatk"), getScore(p, "ksatkt"), 30, 60, "atk"); effect(p, getScore(p, "ksfy"), getScore(p, "ksfyt"), 30, 60, "fy"); tryHotbarRefresh(p); },
  "gold:dy_cxd": (p) => { tell(p, "你食用了 §r§f§l[§gD++§f]§4赤血§f丹"); addScore(p, "hp", 400); },
  "gold:dy_gyd": (p) => { tell(p, "你食用了 §r§f§l[§gD++§f]§e罡元§f丹"); effect(p, getScore(p, "ksatk"), getScore(p, "ksatkt"), 30, 240, "atk"); effect(p, getScore(p, "ksfy"), getScore(p, "ksfyt"), 15, 240, "fy"); tryHotbarRefresh(p); },
  "gold:dy_hcd": (p) => { tell(p, "你食用了 §r§f§l[§gD++§f]§c回春§f丹"); effect(p, getScore(p, "kshx"), getScore(p, "kshxt"), 13, 100, "hx"); tryHotbarRefresh(p); },
  "gold:dy_hld": (p) => { tell(p, "你食用了 §r§f§l[§gD++§f]§b回灵§f丹"); effect(p, getScore(p, "kshl"), getScore(p, "kshlt"), 10, 75, "hl"); tryHotbarRefresh(p); }
};

export function registerConsumables(itemComponentRegistry) {
  // 所有已迁移食物 JSON 都挂载 minecraft:custom_components: ["gold:consume"]。
  // onConsume 能准确表示“食物已经吃完”，比通用 itemUse/itemCompleteUse 更适合食物。
  itemComponentRegistry.registerCustomComponent("gold:consume", {
    onConsume({ source, itemStack }) {
      const handler = handlers[itemStack?.typeId];
      if (!handler || !source || source.typeId !== "minecraft:player") return;
      // 自定义组件回调可能处于受限执行上下文；延迟到下一 tick 后再改分数、效果和标签。
      system.run(() => {
        try { handler(source); } catch (error) { console.warn(`[Gold] consumable ${itemStack.typeId}: ${error}`); }
      });
    }
  });
}
