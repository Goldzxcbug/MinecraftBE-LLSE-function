// 将 tdqw 计分板保存的筑基奇物编号转换为死亡播报/状态标题使用的文本。
export function zjqw(num) {
  switch (Number(num)) {
    case 0: return "";
    case 1: return "【§a虬龙枝§r】";
    case 2: return "【§6锈剑道玄§r】";
    case 3: return "【§0天煞剑意§r】";
    case 4: return "【§5附魔金苹果§r】";
    case 5: return "【§2不眠瞳§r】";
    case 6: return "【§b沧海珠§r】";
    default: return "错误";
  }
}

// 将 gf 计分板编号转换成功法名称；未知编号保留“错误”提示，便于排查存档数据。
export function gf(num) {
  switch (Number(num)) {
    case 0: return "";
    case 1: return "§4▪ §2练气功法：  §r 【§b小衍水决§r】";
    case 301: return "§4▪ §e元婴功法：  §r 【§e千机玉寰金章§r】";
    default: return "错误";
  }
}

// 对准备嵌入命令 JSON/RawText 的普通字符串进行最基本的转义。
// 当前迁移模块暂未直接调用，保留给后续 tellraw/命令文本扩展使用。
export function escapeRawText(text) {
  return String(text).replaceAll("\\", "\\\\").replaceAll('"', '\\"').replaceAll("\n", "\\n");
}
